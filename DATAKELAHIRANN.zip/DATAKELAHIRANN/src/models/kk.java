/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author ASUS
 */
final public class kk {
    public String noKK;
    public String namaKepalaKeluarga;
    public String namaIstri;
    
    public kk(String noKK, String namaKepalaKeluarga, String namaIstri) {
        this.noKK = noKK;
        this.namaKepalaKeluarga = namaKepalaKeluarga;
        this.namaIstri = namaIstri;
    }

    public int noKK() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
